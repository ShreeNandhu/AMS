package com.AirlineReservationSystem.AirlineReservationApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineReservationAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
