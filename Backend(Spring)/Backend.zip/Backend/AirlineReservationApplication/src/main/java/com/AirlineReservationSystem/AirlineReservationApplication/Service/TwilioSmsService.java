package com.AirlineReservationSystem.AirlineReservationApplication.Service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.twilio.Twilio;
import com.twilio.exception.ApiException;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

@Service
public class TwilioSmsService {

	@Value("${twilio.account_sid}")
    private String accountSid;

    @Value("${twilio.auth_token}")
    private String authToken;

    @Value("${twilio.phone_number}")
    private String twilioNumber;

    public void sendSms(String userPhone, String messageBody) {
        Twilio.init(accountSid, authToken);
        if (!userPhone.startsWith("+")) {
            userPhone = "+91" + userPhone;  // Prepend country code if missing
        }

        try {
            Message.creator(
                new PhoneNumber(userPhone), // Ensure phone number is in correct format
                new PhoneNumber(twilioNumber), 
                messageBody
            ).create();
            
            System.out.println("SMS sent successfully to: " + userPhone);
        } catch (ApiException e) {
            System.err.println("Failed to send SMS: " + e.getMessage());
        }
}
}