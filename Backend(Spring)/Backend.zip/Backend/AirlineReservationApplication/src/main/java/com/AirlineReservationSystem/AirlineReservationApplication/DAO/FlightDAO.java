package com.AirlineReservationSystem.AirlineReservationApplication.DAO;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Flight;

@Repository
public interface FlightDAO extends JpaRepository<Flight, Long> {
	
	// Search flights based on source, destination, and departure date
	List<Flight> findBySourceAndDestinationAndDepartureTimeBetween(
	         String source, String destination, LocalDateTime startTime, LocalDateTime endTime);

}
