package com.AirlineReservationSystem.AirlineReservationApplication.DAO;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Booking;

@Repository
public interface BookingDAO extends JpaRepository<Booking, Long> {
	
	 List<Booking> findByFlightId(Long flightId);
	 List<Booking> findByUserId(Long userId);
	 boolean existsByFlightIdAndSeatNumber(Long flightId, int seatNumber);
}
