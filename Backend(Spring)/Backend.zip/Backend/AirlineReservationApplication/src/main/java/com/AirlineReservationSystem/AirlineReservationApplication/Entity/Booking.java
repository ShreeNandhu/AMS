package com.AirlineReservationSystem.AirlineReservationApplication.Entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name = "bookings")
public class Booking {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@ManyToOne
	@JoinColumn(name = "flight_id", nullable = false)
	private Flight flight;

	@NotNull
	private Long userId; // Assuming user authentication is handled

	// Change seatNumber to a list to allow multiple seat bookings
	@Column(name = "seat_number", nullable = false) // Store seat numbers as a String
	private int seatNumber;

	@NotEmpty
	private String bookingStatus; // CONFIRMED, CANCELLED
	private LocalDateTime bookingDate;

	@NotEmpty
	private String paymentStatus; // SUCCESS, PENDING, FAILED

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Flight getFlight() {
		return flight;
	}
	public void setFlight(Flight flight) {
		this.flight = flight;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public int getSeatNumber() {
		return seatNumber;
	}
	public void setSeatNumber(int seatNumber) {
		this.seatNumber = seatNumber;
	}
	public String getBookingStatus() {
		return bookingStatus;
	}
	public void setBookingStatus(String bookingStatus) {
		this.bookingStatus = bookingStatus;
	}
	public LocalDateTime getBookingDate() {
		return bookingDate;
	}
	public void setBookingDate(LocalDateTime bookingDate) {
		this.bookingDate = bookingDate;
	}
	public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}

	public Booking(Flight flight, Long userId, int seatNumber, String bookingStatus,
			LocalDateTime bookingDate, String paymentStatus) {
		super();
		this.flight = flight;
		this.userId = userId;
		this.seatNumber = seatNumber;
		this.bookingStatus = bookingStatus;
		this.bookingDate = bookingDate;
		this.paymentStatus = paymentStatus;
	}
	@Override
	public String toString() {
		return "Booking [id=" + id + ", flight=" + flight + ", userId=" + userId + ", seatNumber=" + seatNumber
				+ ", bookingStatus=" + bookingStatus + ", bookingDate=" + bookingDate + ", paymentStatus="
				+ paymentStatus + "]";
	}
	public Booking() {
		super();
		// TODO Auto-generated constructor stub
	}



}
