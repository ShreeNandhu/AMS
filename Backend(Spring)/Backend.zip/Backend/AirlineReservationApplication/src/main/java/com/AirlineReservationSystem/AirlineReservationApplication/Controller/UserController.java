package com.AirlineReservationSystem.AirlineReservationApplication.Controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.AirlineReservationSystem.AirlineReservationApplication.Entity.User;
import com.AirlineReservationSystem.AirlineReservationApplication.Service.UserService;

import jakarta.validation.Valid;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class UserController {

	@Autowired
	private UserService userService;

	// Register a new user
	@PostMapping("/register")
	public ResponseEntity<User> registerUser(@Valid @RequestBody User user) {
		Optional<User> existingUser = userService.getUserByEmail(user.getEmail());
		if (existingUser.isPresent()) {
			return ResponseEntity.badRequest().body(null); // User with this email already exists
		}
		User createdUser = userService.createUser(user);
		return ResponseEntity.ok(createdUser);
	}

	// Any BAD Request appear return to the Frontend
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<Map<String, String>> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();

		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});

		return ResponseEntity.badRequest().body(errors); // Returns clean JSON errors
	}

	// Getting email and phone number by id for Booking Purpose
	@GetMapping("/{id}")
	public ResponseEntity<?> getUserMobileAndEmail(@PathVariable Long id) {
		Optional<Map<String, String>> userDetails = userService.getUserMobileAndEmail(id);
		return userDetails.map(ResponseEntity::ok)
				.orElseGet(() -> ResponseEntity.notFound().build());
	}
	// Login a user
	@PostMapping("/login")
	public ResponseEntity<Map<String, String>> loginUser(@RequestBody User loginRequest) {
		Optional<User> userOpt = userService.getUserByEmail(loginRequest.getEmail());
		Map<String, String> response = new HashMap<>();
		if (userOpt.isEmpty()) {
			response.put("message", "User not found");
			return ResponseEntity.status(401).body(response);
		}

		User user = userOpt.get();
		if (user.getPassword().equals(loginRequest.getPassword())) {
			response.put("message", "Login successful");
			response.put("name", user.getName());
			response.put("role", user.getRole());
			response.put("id", user.getId().toString());
			return ResponseEntity.ok(response);
		} else {
			response.put("message", "Invalid credentials");
			return ResponseEntity.status(401).body(response);
		}
	}

	//update user profile 
	@PutMapping("/user/update/{email}")
	public ResponseEntity<?> updateUserEmail(@PathVariable String email, @RequestBody Map<String, String> requestBody) {
		Optional<User> userOpt = userService.getUserByEmail(email);
		if (userOpt.isEmpty()) {
			return ResponseEntity.status(404).body(Map.of("message", "User not found"));
		}

		User user = userOpt.get();
		String newEmail = requestBody.get("email");

		// Check if the new email is provided and is different
		if (newEmail == null || newEmail.isEmpty() || newEmail.equals(user.getEmail())) {
			return ResponseEntity.badRequest().body(Map.of("message", "Invalid or same email provided"));
		}

		// Check if the email already exists (optional step)
		if (userService.getUserByEmail(newEmail).isPresent()) {
			return ResponseEntity.status(409).body(Map.of("message", "Email already in use"));
		}

		user.setEmail(newEmail);
		userService.createUser(user); // Save updated user

		return ResponseEntity.ok(Map.of("message", "Email updated successfully"));
	}

	//Change user password
	@PutMapping("/user/change-password/{userId}")
	public ResponseEntity<?> changePassword(@PathVariable Long userId, @RequestBody Map<String, String> request) {
		String newPassword = request.get("newPassword");

		if (newPassword == null || newPassword.trim().isEmpty()) {
			return ResponseEntity.badRequest().body(Map.of("message", "New password is required"));
		}

		Optional<User> userOpt = userService.getUserById(userId);
		if (userOpt.isEmpty()) {
			return ResponseEntity.status(404).body(Map.of("message", "User not found"));
		}

		userService.updateUserPassword(userId, newPassword);
		return ResponseEntity.ok(Map.of("message", "Password changed successfully"));
	}


	//delete user Account
	@DeleteMapping("user/delete/{id}")
	public ResponseEntity<Map<String, String>> deleteEmployee(@PathVariable Long id) {
		boolean deleted = userService.deleteUser(id);

		if (deleted) {
			return ResponseEntity.ok(Map.of("message", "Employee deleted successfully"));
		} else {
			return ResponseEntity.status(404).body(Map.of("message", "Employee not found"));
		}
	}

}
