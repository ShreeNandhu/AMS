package com.AirlineReservationSystem.AirlineReservationApplication.Service;

import java.io.FileOutputStream;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.AirlineReservationSystem.AirlineReservationApplication.DAO.BookingDAO;
import com.AirlineReservationSystem.AirlineReservationApplication.DAO.FlightDAO;
import com.AirlineReservationSystem.AirlineReservationApplication.DAO.UserDAO;
import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Booking;
import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Flight;
import com.AirlineReservationSystem.AirlineReservationApplication.Entity.User;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import jakarta.transaction.Transactional;


@Transactional
@Service
public class BookingService {
	@Autowired
	private BookingDAO bookingDAO;

	@Autowired
	private FlightDAO flightDAO;

	@Autowired
	private UserDAO userDAO;

	@Autowired
	private TwilioSmsService smsService;

	@Autowired
	private EmailService emailService;

	public String bookSeat(Long flightId, Long userId, int seatNumber) {
		Optional<Flight> flightOptional = flightDAO.findById(flightId);

		if (flightOptional.isEmpty()) {
			return "Flight not found!";
		}

		Flight flight = flightOptional.get();

		// Validate seat number
		if (seatNumber <= 0 || seatNumber > flight.getTotalSeats()) {
			return "Invalid seat number!";
		}

		// Check if seat is already booked
		if (bookingDAO.existsByFlightIdAndSeatNumber(flightId, seatNumber)) {
			return "Seat " + seatNumber + " is already booked!";
		}

		// Create a new booking
		Booking booking = new Booking(flight, userId, seatNumber, "CONFIRMED", LocalDateTime.now(), "PENDING");

		// Save booking and update flight
		Booking savedBooking = bookingDAO.save(booking);
		flight.bookSeat();
		flightDAO.save(flight);

		return String.valueOf(savedBooking.getId());
	}


	//processing payment
	@Transactional
	public String processPayment(Long bookingId, String paymentMethod, double amount) {
		Optional<Booking> bookingOptional = bookingDAO.findById(bookingId);
		if (bookingOptional.isEmpty()) return "Booking not found!";

		Booking booking = bookingOptional.get();

		if (amount < booking.getFlight().getPrice()) {
			return "Payment failed! Insufficient amount.";
		}
		// Simulating successful payment
		booking.setPaymentStatus("PAID");
		bookingDAO.save(booking);

		// Generate ticket after successful payment
		String ticketPath = generateTicket(booking);

		// Send Email to User
		Optional<User> userOptional = userDAO.findById(booking.getUserId());
		if (userOptional.isPresent()) { // Ensure user exists
			User user = userOptional.get(); // Extract user
			if (user != null && user.getEmail() != null) {
				String subject = "Your Flight Ticket - Booking ID: " + bookingId;
				String body = "Dear " + user.getName() + ",\n\n" +
						"Your ticket for Flight " + booking.getFlight().getAirline() +
						" has been successfully booked.\n\n" +
						"Booking ID: " + bookingId + "\n" +
						"Seat Number: " + booking.getSeatNumber() + "\n\n" +
						"Your ticket is attached with this email.\n\n" +
						"Thank you for choosing us!";

				emailService.sendEmailWithAttachment(user.getEmail(), subject, body, ticketPath);
			}
		}

		return "Payment successful! Ticket generated and email sent for Booking ID: " + bookingId;
	}

	public String generateTicket(Booking booking) {
		Document document = new Document();
		try {
			String fileName = "Ticket_Booking_" + booking.getId() + ".pdf";
			FileOutputStream fos = new FileOutputStream(fileName);

			// Correct method signature for iText 5
			PdfWriter writer = PdfWriter.getInstance(document, fos);

			document.open();

			// Check if booking and flight details exist
			if (booking == null || booking.getFlight() == null) {
				System.out.println("❌ Error: Booking or Flight details are missing!");

			}

			// Using FontFactory (recommended in iText 5)
			Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 18);
			Font normalFont = FontFactory.getFont(FontFactory.HELVETICA, 12);

			// Ticket Details
			document.add(new Paragraph("Airline Reservation System - Ticket", titleFont));
			document.add(new Paragraph("-------------------------------------------------------------"));
			document.add(new Paragraph("Booking ID: " + booking.getId(), normalFont));
			document.add(new Paragraph("Flight: " + booking.getFlight().getAirline(), normalFont));
			document.add(new Paragraph("Source: " + booking.getFlight().getSource(), normalFont));
			document.add(new Paragraph("Destination: " + booking.getFlight().getDestination(), normalFont));
			document.add(new Paragraph("Departure Time: " + booking.getFlight().getDepartureTime(), normalFont));
			document.add(new Paragraph("Seat Number: " + booking.getSeatNumber(), normalFont));
			document.add(new Paragraph("Booking Status: " + booking.getBookingStatus(), normalFont));
			document.add(new Paragraph("Payment Status: " + booking.getPaymentStatus(), normalFont));

			document.close();
			writer.close();
			fos.close();
			System.out.println("✅ Ticket generated successfully: " + fileName);
			return fileName; // Return file path for email attachment
		} catch (Exception e) {
			System.err.println("❌ Error while generating ticket: " + e.getMessage());
			e.printStackTrace();
		}
		return null;
	}

	@Transactional
	public ResponseEntity<Map<String, String>> cancelBooking(Long bookingId) {
	    Optional<Booking> bookingOptional = bookingDAO.findById(bookingId);
	    if (bookingOptional.isEmpty()) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                .body(Collections.singletonMap("message", "Booking not found!"));
	    }

	    Booking booking = bookingOptional.get();
	    Long flightId = booking.getFlight().getId();
	    Long userId = booking.getUserId();
	    Integer seatNumber = booking.getSeatNumber();

	    Optional<Flight> flightOptional = flightDAO.findById(flightId);
	    if (flightOptional.isEmpty()) {
	        return ResponseEntity.status(HttpStatus.NOT_FOUND)
	                .body(Collections.singletonMap("message", "Flight not found!"));
	    }

	    Flight flight = flightOptional.get();
	    flight.getBookedSeats().removeIf(b -> b.getId().equals(bookingId));
	    
	    flight.cancelSeat();
	    flightDAO.save(flight);
	    bookingDAO.delete(booking);

	    Optional<User> userOptional = userDAO.findById(userId);
	    if (userOptional.isPresent()) {
	        User user = userOptional.get();
	        String userPhone = user.getPhoneNumber();
	        if (userPhone != null && !userPhone.isEmpty()) {
	            String message = "Booking with ID " + bookingId + 
	                    " has been successfully canceled for flight " + flight.getAirline();
	            smsService.sendSms(userPhone, message);
	        }
	    }

	    Map<String, String> response = new HashMap<>();
	    response.put("message", "Booking with ID " + bookingId + " has been successfully canceled.");
	    
	    return ResponseEntity.ok(response);
	}


	public List<Integer> getAvailableSeats(Long flightId) {
		Optional<Flight> flightOptional = flightDAO.findById(flightId);
		if (flightOptional.isEmpty()) return List.of(); // Return empty list if flight not found

		Flight flight = flightOptional.get();
		List<Integer> allSeats = IntStream.rangeClosed(1, flight.getTotalSeats()).boxed().collect(Collectors.toList());
		//allSeats.removeAll(flight.getBookedSeats()); // Remove booked seats from the list
		List<Integer> bookedSeatNumbers = flight.getBookedSeats().stream()
				.map(Booking::getSeatNumber)
				.collect(Collectors.toList());

		allSeats.removeAll(bookedSeatNumbers); 

		return allSeats; // Return list of available seats
	}


	public List<Booking> getAllBookings() {
		return bookingDAO.findAll();
	}
	
	public Optional<Booking> getBookingById(Long bookingId) {
		return bookingDAO.findById(bookingId);
	}

	public List<Booking> getBookingsByUserId(Long userId) {
		return bookingDAO.findByUserId(userId);
	}
}
