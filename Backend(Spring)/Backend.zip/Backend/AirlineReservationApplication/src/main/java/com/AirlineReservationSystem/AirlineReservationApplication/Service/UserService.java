package com.AirlineReservationSystem.AirlineReservationApplication.Service;

import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AirlineReservationSystem.AirlineReservationApplication.DAO.UserDAO;
import com.AirlineReservationSystem.AirlineReservationApplication.Entity.User;

import jakarta.transaction.Transactional;

@Service
public class UserService {
	@Autowired
    private UserDAO userDao;

    // Create a new user
    public User createUser(User user) {
        return userDao.save(user);
    }
    //Find the User by Id
    public Optional<Map<String, String>> getUserMobileAndEmail(Long userId) {
        return userDao.findById(userId).map(user -> Map.of(
            "email", user.getEmail(),
            "phoneNumber", user.getPhoneNumber()
        ));
    }
    public Optional<User> getUserById(Long userId) {
        return userDao.findById(userId);
    }
 // Find a user by email (for login purposes)
    public Optional<User> getUserByEmail(String email) {
        return userDao.findByEmail(email);
    }
    
    @Transactional
    public void updateUserPassword(Long userId, String newPassword) {
        Optional<User> userOpt = userDao.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setPassword(newPassword); // Consider encoding the password before saving
            userDao.save(user);
        }
    }

	public boolean deleteUser(Long id) {
		if (userDao.existsById(id)) {
            userDao.deleteById(id);
            return true;
        };
        return false;
	}

}
