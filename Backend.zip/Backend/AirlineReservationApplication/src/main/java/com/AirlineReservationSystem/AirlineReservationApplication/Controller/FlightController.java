package com.AirlineReservationSystem.AirlineReservationApplication.Controller;

import java.time.LocalDate;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Flight;
import com.AirlineReservationSystem.AirlineReservationApplication.Service.FlightService;


@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/flights")
public class FlightController {
	@Autowired
	private FlightService flightService;

	// Get all flights
	@GetMapping
	public List<Flight> getAllFlights() {
		return flightService.getAllFlights();
	}

	// Search flights by source, destination, and date (Using Request Body without DTO)
	@PostMapping("/search")
	public List<Flight> searchFlights(@RequestBody Map<String, Object> requestBody) {
		String source = (String) requestBody.get("source");
		String destination = (String) requestBody.get("destination");

		// Parse LocalDate from request body
		LocalDate date = LocalDate.parse((String) requestBody.get("date"));

		return flightService.searchFlights(source, destination, date);
	}
	
	// Fetch the Location of the Flights
	@GetMapping("/locations")
	public ResponseEntity<Map<String, List<String>>> getFlightLocations() {
	    List<String> sources = flightService.getAllFlights().stream()
	            .map(Flight::getSource)
	            .distinct()
	            .collect(Collectors.toList());

	    List<String> destinations = flightService.getAllFlights().stream()
	            .map(Flight::getDestination)
	            .distinct()
	            .collect(Collectors.toList());

	    Map<String, List<String>> locations = new HashMap<>();
	    locations.put("sources", sources);
	    locations.put("destinations", destinations);

	    return ResponseEntity.ok(locations);
	}

	// Add a new flight by admin
	@PostMapping("/add")
	public ResponseEntity<Map<String, Object>> addFlight(@RequestBody Flight flight) {
		Flight savedFlight = flightService.addFlight(flight);
		Map<String, Object> response = new HashMap<>();
		response.put("message", "Flight added successfully");
		return ResponseEntity.ok(response);
	}

	// Update flight details by admin
	@PutMapping("/update/{id}")
	public ResponseEntity<Map<String, Object>> updateFlight(@PathVariable Long id, @RequestBody Flight updatedFlight) {
		Optional<Flight> existingFlight = flightService.getFlightById(id);

		if (existingFlight.isPresent()) {
			Flight flight = flightService.updateFlight(id, updatedFlight);

			// ✅ Wrap the success message and flight data in a JSON object
			Map<String, Object> response = new HashMap<>();
			response.put("message", "Flight updated successfully");
			response.put("flight", flight);

			return ResponseEntity.ok(response);
		} else {
			return ResponseEntity.status(404).body(Collections.singletonMap("message", "Flight not found"));
		}
	}

	// Delete flight by Admin
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Map<String, String>> deleteFlight(@PathVariable Long id) {
		Optional<Flight> existingFlight = flightService.getFlightById(id);

		if (existingFlight.isPresent()) {
			flightService.deleteFlight(id);
			return ResponseEntity.ok(Collections.singletonMap("message", "Flight with ID " + id + " deleted successfully. SMS sent successfully to user."));
		} else {
			return ResponseEntity.status(404).body(Collections.singletonMap("error", "Flight with ID " + id + " not found."));
		}
	}
}
