package com.AirlineReservationSystem.AirlineReservationApplication.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.AirlineReservationSystem.AirlineReservationApplication.DAO.BookingDAO;
import com.AirlineReservationSystem.AirlineReservationApplication.DAO.FlightDAO;
import com.AirlineReservationSystem.AirlineReservationApplication.DAO.UserDAO;
import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Booking;
import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Flight;
import com.AirlineReservationSystem.AirlineReservationApplication.Entity.User;

@Service
public class FlightService {

	@Autowired
	private FlightDAO flightDAO;

	@Autowired
	private BookingDAO bookingDAO;

	@Autowired
	private UserDAO userDAO;

	@Autowired
	private TwilioSmsService smsService;

	// Get flight by ID
	public Optional<Flight> getFlightById(Long id) {
		return flightDAO.findById(id);
	}

	// Get all flights
	public List<Flight> getAllFlights() {
		return flightDAO.findAll();
	}

	// Search flights by source, destination, and date
	public List<Flight> searchFlights(String source, String destination, LocalDate date) {
		// Convert date to start and end of the day
		LocalDateTime startTime = date.atStartOfDay(); // 00:00:00
		LocalDateTime endTime = date.atTime(LocalTime.MAX); // 23:59:59

		return flightDAO.findBySourceAndDestinationAndDepartureTimeBetween(source, destination, startTime, endTime);
	}

	// Add a new flight (Admin)
	public Flight addFlight(Flight flight) {
		return flightDAO.save(flight);
	}

	// Update flight details (Admin)
	public Flight updateFlight(Long id, Flight updatedFlight) {
		Optional<Flight> existingFlight = flightDAO.findById(id);
		if (existingFlight.isPresent()) {
			Flight flight = existingFlight.get();
			flight.setAirline(updatedFlight.getAirline());
			flight.setSource(updatedFlight.getSource());
			flight.setDestination(updatedFlight.getDestination());
			flight.setArrivalTime(updatedFlight.getArrivalTime());			
			flight.setDepartureTime(updatedFlight.getDepartureTime());
			flight.setAvailableSeats(updatedFlight.getAvailableSeats());
			flight.setPrice(updatedFlight.getPrice());
			flight.setTotalSeats(updatedFlight.getTotalSeats());
			flight.setAvailableSeats(updatedFlight.getTotalSeats());
			return flightDAO.save(flight);
		}
		return null;
	}

	// Delete flight (Admin)
	public String deleteFlight(Long id) {
		/*if (flightDAO.existsById(id)) {
            flightDAO.deleteById(id);
            return "Flight deleted successfully!";
        }
        return "Flight not found!";*/
		Optional<Flight> flightOptional = flightDAO.findById(id);
		if (flightOptional.isEmpty()) {
			return "Flight not found!";
		}

		Flight flight = flightOptional.get();

		// ✅ Find all affected bookings
		List<Booking> affectedBookings = bookingDAO.findByFlightId(id);

		// Send SMS notifications
		for (Booking booking : affectedBookings) {
			Optional<User> userOptional = userDAO.findById(booking.getUserId()); // Get user details
			if (userOptional.isPresent()) { // ✅ Check if user exists
				User user = userOptional.get(); // ✅ Extract the user object
				String userPhone = user.getPhoneNumber(); // ✅ Get phone number
			if (userPhone != null && !userPhone.isEmpty()) {
				String message = "Dear Passenger, your flight from " 
						+ flight.getSource() + " to " + flight.getDestination() 
						+ " on " + flight.getDepartureTime() + " has been canceled. "
						+ "Please contact support for further assistance.";
				smsService.sendSms(userPhone, message);
			}
		}
		}
		// ✅ Delete all bookings related to the flight
		bookingDAO.deleteAll(affectedBookings);

		// ✅ Delete the flight itself
		flightDAO.delete(flight);

		return "Flight with ID " + id + " and all associated bookings have been canceled.";
	}

}
