package com.AirlineReservationSystem.AirlineReservationApplication.Entity;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.*;


@Entity
@Table(name = "flights")
public class Flight {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long flightId;

	private String airline;
	private String source;
	private String destination;
	private LocalDateTime arrivalTime;   // Changed to LocalDateTime
	private LocalDateTime departureTime; // Changed to LocalDateTime
	private double price;
	private int totalSeats;  
	private int availableSeats; 
	// Seats that are still available

	@OneToMany(mappedBy = "flight", cascade = CascadeType.ALL, orphanRemoval = true)
	@JsonIgnore
	private List<Booking> bookedSeats = new ArrayList<>();// Store booked seats separate


	public Flight() {}

	// Parameterized Constructor
	public Flight(Long id, String airline, String source, String destination, LocalDateTime departureTime,
			LocalDateTime arrivalTime, double price, int totalSeats, List<Booking> bookedSeats) {
		this.flightId = id;
		this.airline = airline;
		this.source = source;
		this.destination = destination;
		this.departureTime = departureTime;
		this.arrivalTime = arrivalTime;
		this.price = price;
		this.totalSeats = totalSeats;
		this.availableSeats = totalSeats;
		this.bookedSeats = bookedSeats;
	}

	// Getters & Setters
	public Long getId() {
		return flightId;
	}

	public void setId(Long id) {
		this.flightId = id;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public LocalDateTime getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(LocalDateTime arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public LocalDateTime getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(LocalDateTime departureTime) {
		this.departureTime = departureTime;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
		this.availableSeats = totalSeats;
	}

	public int getAvailableSeats() {
		return totalSeats - bookedSeats.size();
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public List<Booking> getBookedSeats() {
		return bookedSeats;
	}

	public void setBookedSeats( List<Booking> bookedSeats) {
		this.bookedSeats = bookedSeats;
	}

	@JsonProperty("bookedSeats")
	public List<Integer> getBookedSeatNumbers() {
		return bookedSeats.stream()
				.map(Booking::getSeatNumber)
				.collect(Collectors.toList());
	}

	@JsonIgnore
	public List<Integer> getAvailableSeatNumbers() {
		List<Integer> allSeats = IntStream.rangeClosed(1, totalSeats).boxed().collect(Collectors.toList());
		allSeats.removeAll(getBookedSeatNumbers());
		return allSeats;
	}

	// Book a seat
	public void bookSeat() {
		if (availableSeats > 0) {
			availableSeats--;
		} else {
			throw new IllegalStateException("No available seats left");
		}
	}

	// Cancel a booked seat
	public void cancelSeat() {
		if (availableSeats < totalSeats) {
			availableSeats++;
		}
	}

	@Override
	public String toString() {
		return "Flight [id=" + flightId + ", airline=" + airline + ", source=" + source + ", destination=" + destination
				+ ", departureTime=" + departureTime + ", arrivalTime=" + arrivalTime + ", price=" + price
				+ ", totalSeats=" + totalSeats + ", availableSeats=" + availableSeats + "]";
	}
}

