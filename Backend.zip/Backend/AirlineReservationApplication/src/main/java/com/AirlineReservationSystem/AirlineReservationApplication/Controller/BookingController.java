package com.AirlineReservationSystem.AirlineReservationApplication.Controller;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.AirlineReservationSystem.AirlineReservationApplication.Entity.Booking;
import com.AirlineReservationSystem.AirlineReservationApplication.Service.BookingService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/bookings")
public class BookingController {
	@Autowired
	private BookingService bookingService;
    
	//Book a Ticket 
	@PostMapping("/book")
	public ResponseEntity<?> bookSeat(@RequestBody Map<String, Object> bookingRequest) {
		try {
			// Validate request parameters
			if (!bookingRequest.containsKey("flightId") || bookingRequest.get("flightId") == null) {
				return ResponseEntity.badRequest().body(Map.of("error", "Flight ID cannot be null!"));
			}
			if (!bookingRequest.containsKey("userId") || bookingRequest.get("userId") == null) {
				return ResponseEntity.badRequest().body(Map.of("error", "User ID cannot be null!"));
			}
			if (!bookingRequest.containsKey("seatNumber") || bookingRequest.get("seatNumber") == null) {
				return ResponseEntity.badRequest().body(Map.of("error", "Seat number cannot be null!"));
			}

			// Extract and convert parameters safely
			Long flightId = ((Number) bookingRequest.get("flightId")).longValue();
			Long userId = ((Number) bookingRequest.get("userId")).longValue();
			int seatNumber = ((Number) bookingRequest.get("seatNumber")).intValue();

			// Call service method and return response
			String response = bookingService.bookSeat(flightId, userId, seatNumber);

			// If the seat is already booked, return an error
			if (response.startsWith("Seat")) {
				return ResponseEntity.badRequest().body(Map.of("error", response));
			}

			return ResponseEntity.ok(Map.of(
					"message", "Seat was Booked Successfully",
					"bookingId", response
					));
		} catch (ClassCastException e) {
			return ResponseEntity.badRequest().body(Map.of("error", "Invalid data format! Ensure flightId, userId, and seatNumber are numbers."));
		} catch (Exception e) {
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body(Map.of("error", "An unexpected error occurred: " + e.getMessage()));
		}
	}
    
	//  Get Booking by ID
    @GetMapping("/id/{bookingId}")
    public ResponseEntity<Booking> getBookingById(@PathVariable Long bookingId) {
        Optional<Booking> booking = bookingService.getBookingById(bookingId);

        return booking.map(ResponseEntity::ok)
                      .orElseGet(() -> ResponseEntity.notFound().build());
    }
    
	// Cancel Tickets
	@DeleteMapping("/cancel/{bookingId}")
	public ResponseEntity<Map<String, ResponseEntity<Map<String, String>>>> cancelBooking(@PathVariable Long bookingId) {
	    ResponseEntity<Map<String, String>> message = bookingService.cancelBooking(bookingId);
	    return ResponseEntity.ok(Collections.singletonMap("message", message));
	}


	//Fetch Available Seats for Particular Flight
	@GetMapping("/availableSeats/{flightId}")
	public ResponseEntity<Integer> getAvailableSeats(@PathVariable Long flightId) {
		int availableSeatsCount = bookingService.getAvailableSeats(flightId).size(); // ✅ Return only count
		return ResponseEntity.ok(availableSeatsCount);
	}

	//Fetch a Booking History for Particular User
	@GetMapping("/user/{userId}")
	public ResponseEntity<List<Booking>> getBookingsByUserId(@PathVariable String userId) {
		try {
			Long id = Long.parseLong(userId); // Convert String to Long
			return ResponseEntity.ok(bookingService.getBookingsByUserId(id));
		} catch (NumberFormatException e) {
			return ResponseEntity.badRequest().build();
		}
	}

	// View all bookings(Admin)
	@GetMapping("/all")
	public ResponseEntity<List<Booking>> getAllBookings() {
		return ResponseEntity.ok(bookingService.getAllBookings());
	}
	//payment 
	@PostMapping("/processPayment")
	public ResponseEntity<?> processPayment(@RequestBody Map<String, Object> paymentRequest) {
		try {
			// Extract the payment request parameters
			Long bookingId = Long.parseLong(paymentRequest.get("bookingId").toString());
			String paymentMethod = paymentRequest.get("paymentMethod").toString();
			double amount = Double.parseDouble(paymentRequest.get("amount").toString());

			// Call service method to process the payment
			String paymentResponse = bookingService.processPayment(bookingId, paymentMethod, amount);

			// If payment is successful, return a success response
			return ResponseEntity.ok(Map.of("message", paymentResponse)); // This sends back the response from the service (e.g., success message)
		} catch (Exception e) {
			// Handle errors (e.g., invalid data format or payment processing failure)
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
					.body("Payment failed: " + e.getMessage());
		}
	}




}
