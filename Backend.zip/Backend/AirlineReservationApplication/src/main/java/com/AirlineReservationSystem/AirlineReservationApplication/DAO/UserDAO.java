package com.AirlineReservationSystem.AirlineReservationApplication.DAO;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.AirlineReservationSystem.AirlineReservationApplication.Entity.User;


public interface UserDAO extends JpaRepository<User, Long> {
	
	// Find user by email (useful for authentication or uniqueness checks)
    Optional<User> findByEmail(String email);
    
    
    @Modifying
    @Query("UPDATE User u SET u.password = :newPassword WHERE u.id = :userId")
    void updatePasswordById(@Param("userId") Long userId, @Param("newPassword") String newPassword);


}
